public class FizzBuzzTest {
    public static void main(String[] args){
        FizzBuzz iD = new FizzBuzz();
        String test = iD.fizzBuzz(50);
        System.out.println(test);
    }
}