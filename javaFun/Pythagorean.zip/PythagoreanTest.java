public class PythagoreanTest {
    public static void main(String[] args) {
        Pythagorean iD = new Pythagorean();
        double hypotenuse = iD.calculateHypotenuse(1,1);
        System.out.println(hypotenuse);
    }
}