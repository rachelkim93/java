public class ListTester {
    public static void main(String[] args){
        SLL list = new SLL();
        list.add(5).add(6).add(76).add(-26).add(9).add(0).remove();
        list.removeAt(0);
        list.printValues();
    }
}